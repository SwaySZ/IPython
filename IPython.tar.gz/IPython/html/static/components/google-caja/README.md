# google-caja

This is the javascript portion of the [Google Caja][] HTML sanitizer,
so that it can be installed as a [Bower][] package.

[google-caja]: https://developers.google.com/caja/
[bower]: http://bower.io/

## License

Since this is just packaging of another project,
any code here is licensed under Apache 2.0,
the same license of the Google Caja itself.
